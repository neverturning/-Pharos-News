package com.wan.pharosnews.service.impl;

import com.github.pagehelper.PageHelper;

import com.wan.pharosnews.dao.CommentMapper;
import com.wan.pharosnews.dao.NewsMapper;
import com.wan.pharosnews.dao.StatisticMapper;
import com.wan.pharosnews.model.ResponseDate.StaticticsBo;
import com.wan.pharosnews.model.domain.Comment;
import com.wan.pharosnews.model.domain.News;
import com.wan.pharosnews.model.domain.Statistic;
import com.wan.pharosnews.service.SiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @Classname SiteServiceImpl
 * @Description TODO
 * @Date 2019-3-14 10:15
 * @Created by CrazyStone
 */
@Service
@Transactional
public class SiteServiceImpl implements SiteService {
    @Autowired
    private CommentMapper commentMapper;
    @Autowired
    private NewsMapper newsMapper;
    @Autowired
    private StatisticMapper statisticMapper;

    @Override
    public List<Comment> recentComments(int limit) {
        PageHelper.startPage(1, limit>10 || limit<1 ? 10:limit);
        List<Comment> byPage = commentMapper.selectNewComment();
        return byPage;
    }

    @Override
    public List<News> recentNews(int limit) {
        PageHelper.startPage(1, limit>10 || limit<1 ? 10:limit);
        List<News> list = newsMapper.selectNewsWithPage();
        // 封装文章统计数据
        for (int i = 0; i < list.size(); i++) {
           News news = list.get(i);
            Statistic statistic = statisticMapper.findStatisticByNewId(news.getId());
            news.setHits(statistic.getHits());
            news.setCommentsNum(statistic.getCommentsNum());
        }
        return list;
    }

    @Override
    public StaticticsBo getStatistics() {
        StaticticsBo staticticsBo = new StaticticsBo();
        Integer news = newsMapper.countNews();
        Integer comments = commentMapper.countComment();
        staticticsBo.setNews(news);
        staticticsBo.setComments(comments);
        return staticticsBo;
    }

    @Override
    public void updateStatistics(News news) {
        Statistic statistic = statisticMapper.findStatisticByNewId(news.getId());
        statistic.setHits(statistic.getHits()+1);
        statisticMapper.updateNewsHitsWithId(statistic);

    }
}

