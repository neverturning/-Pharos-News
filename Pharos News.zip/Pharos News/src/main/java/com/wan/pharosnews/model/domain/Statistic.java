package com.wan.pharosnews.model.domain;

public class Statistic {
    private Integer id;
    private Integer newId;
    private Integer hits;
    private Integer commentsNum;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNewId() {
        return newId;
    }

    public void setNewId(Integer newId) {
        this.newId = newId;
    }

    public Integer getHits() {
        return hits;
    }

    public void setHits(Integer hits) {
        this.hits = hits;
    }

    public Integer getCommentsNum() {
        return commentsNum;
    }

    public void setCommentsNum(Integer commentsNum) {
        this.commentsNum = commentsNum;
    }

    @Override
    public String toString() {
        return "Statistic{" +
                "id=" + id +
                ", newId=" + newId +
                ", hits=" + hits +
                ", commentsNum=" + commentsNum +
                '}';
    }
}
