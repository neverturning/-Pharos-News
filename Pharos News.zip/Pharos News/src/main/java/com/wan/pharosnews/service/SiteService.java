package com.wan.pharosnews.service;



import com.wan.pharosnews.model.ResponseDate.StaticticsBo;
import com.wan.pharosnews.model.domain.Comment;
import com.wan.pharosnews.model.domain.News;

import java.util.List;

/**
 * @Classname ISiteService
 * @Description 博客站点统计服务
 * @Date 2019-3-14 10:13
 * @Created by CrazyStone
 */
public interface SiteService {
    // 最新收到的评论
    public List<Comment> recentComments(int count);

    // 最新发表的文章
    public List<News> recentNews(int count);

    // 获取后台统计数据
    public StaticticsBo getStatistics();

    // 更新某个文章的统计数据
    public void updateStatistics(News news);
}

