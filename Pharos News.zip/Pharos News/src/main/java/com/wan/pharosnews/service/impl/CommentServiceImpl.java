package com.wan.pharosnews.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wan.pharosnews.dao.CommentMapper;
import com.wan.pharosnews.dao.StatisticMapper;
import com.wan.pharosnews.model.domain.Comment;
import com.wan.pharosnews.model.domain.Statistic;
import com.wan.pharosnews.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CommentServiceImpl implements CommentService {
    @Autowired
    private CommentMapper commentMapper;
    @Autowired
    private StatisticMapper statisticMapper;
//    @Autowired
//    private RedisTemplate redisTemplate;

    @Override
    public PageInfo<Comment> getComments(Integer id, int page, int count) {
        PageHelper.startPage(page,count);
        List<Comment> commentList = commentMapper.selectCommentWithPage(id);
        PageInfo<Comment> commentInfo = new PageInfo<>(commentList);
        return commentInfo;
    }
//todo 用户发表评论
    @Override
    public void pushComment(Comment comment) {
        commentMapper.pushComment(comment);
        Statistic statistic = statisticMapper.findStatisticByNewId(comment.getNewid());
        statistic.setCommentsNum(statistic.getCommentsNum()+1);
        statisticMapper.updateNewsCommentsWithId(statistic);

    }

    @Override
    public List<Comment> selectAllComment() {
        List<Comment> commentList = commentMapper.selectNewComment();
        return commentList;
     }

    @Override
    public void deleteCommentById(int id) {
        commentMapper.deleteCommentById(id);
    }


}
