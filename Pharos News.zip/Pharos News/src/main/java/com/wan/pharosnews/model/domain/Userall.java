package com.wan.pharosnews.model.domain;

/**
 * @program: pharos-news
 * @description:
 * @author: wan
 * @create: 2022-04-05 22:40
 **/

public class Userall {
    private Integer id;
    private String username;
    private String authoritystatus;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }


    public String getAuthoritystatus() {
        return authoritystatus;
    }

    public void setAuthoritystatus(String authoritystatus) {
        this.authoritystatus = authoritystatus;
    }

    @Override
    public String toString() {
        return "Userall{" +
                "id='" + id + '\'' +
                ", username='" + username + '\'' +
                ", authoritystatus='" + authoritystatus + '\'' +
                '}';
    }
}
