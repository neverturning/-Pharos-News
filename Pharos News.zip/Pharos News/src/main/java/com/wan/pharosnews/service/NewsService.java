package com.wan.pharosnews.service;

import com.github.pagehelper.PageInfo;
import com.wan.pharosnews.model.domain.News;


import java.util.List;


public interface NewsService {
    // 分页查询新闻列表
    public PageInfo<News> selectNewsWithPage(Integer page, Integer count);

    public PageInfo<News> selectNewBytitle(Integer page, Integer count,String title);

    // 统计前10的热度新闻信息
    public List<News> getHeatNews();

    // 根据新闻id查询单个新闻详情
    public News selectNewsId (Integer id);

//    // 发布新闻
    public void publish(News news);

    // 根据主键更新新闻
    public void updateNewsWithId(News news) ;

    // 根据主键删除新闻
    public void deleteNewsWithId(int id);
}

