package com.wan.pharosnews.dao;

import com.wan.pharosnews.model.domain.News;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface NewsMapper {


    //新闻分页查询, todo  根据ID降序查找，由大到小  好处：最新发布显示在最前
    @Select("SELECT * FROM new ORDER BY id DESC")
    public List<News> selectNewsWithPage();

    @Select(" SELECT * FROM NEW WHERE title LIKE concat('%',#{title},'%') ORDER BY id DESC")
    public List<News> selectNewBytitle(String title);


    //TODO 根据ID查询新闻信息 新闻ID为id
    @Select("select * from new where id = #{id}")
    public News selectNewsId (Integer id);





    //TODO 发表新闻，并获取自动生成的主键
    @Insert("INSERT INTO new(title,createdate,modified,tags,categories," +
            " allowcomment, photo, content)" +
            " VALUES (#{title},#{createdate}, #{modified}, #{tags}, #{categories}," +
            " #{allowcomment}, #{photo}, #{content})")
    @Options(useGeneratedKeys = true, keyProperty = "id",keyColumn = "id")
    public Integer publishNews(News news);


    //通过ID删除新闻
    @Delete("delete from new where id = #{id} ")
    public void deleteNewsWithId(int id);

    //TODO 站点服务统计，统计新闻数量
    @Select("SELECT COUNT(1) FROM new")
    public Integer countNews();

    //TODO 通过ID更新文章  在 Newsmapper.xml中有具体的配置
    public Integer updateNewsWithId(News news);






}
