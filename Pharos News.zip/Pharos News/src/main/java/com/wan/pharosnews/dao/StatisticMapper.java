package com.wan.pharosnews.dao;

import com.wan.pharosnews.model.domain.News;
import com.wan.pharosnews.model.domain.Statistic;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface StatisticMapper {
    // 新增新闻对应的统计信息
    @Insert("INSERT INTO statistic(newid,hits,commentsnum) values (#{id},0,0)")
    public void addStatistic(News news);

    // 根据新闻id查询点击量和评论量相关信息
    @Select("SELECT * FROM statistic WHERE newid=#{newId}")
    public Statistic findStatisticByNewId(Integer newId);

    // 统计新闻热度信息
    @Select("SELECT * FROM statistic WHERE hits !='0' " +
            "ORDER BY hits DESC, commentsnum DESC")
    public List<Statistic> getStatistic();

    // 通过新闻id更新点击量
    @Update("UPDATE statistic SET hits=#{hits} " +
            "WHERE newid=#{newId}")
    public void updateNewsHitsWithId(Statistic statistic);

    // 通过新闻id更新评论量
    @Update("UPDATE statistic SET commentsnum=#{commentsNum} " +
            "WHERE newid=#{newId}")
    public void updateNewsCommentsWithId(Statistic statistic);

    // 根据新闻id删除统计数据
    @Delete("DELETE FROM statistic WHERE newid=#{id}")  //aid
    public void deleteStatisticWithId(int id);



    // 统计新闻总访问量
    @Select("SELECT SUM(hits) FROM statistic")
    public long getTotalVisit();

    // 统计新闻总评论量
    @Select("SELECT SUM(commentsnum) FROM statistic")
    public long getTotalComment();
}
