package com.wan.pharosnews.utils;

import com.vdurmont.emoji.EmojiParser;
import com.wan.pharosnews.model.domain.News;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class Commons {
    /**
     * 网站链接
     *
     * @return
     */
    public static String site_url() {
        return site_url("/page/1");
    }
    /**
     * 返回网站链接下的全址
     *
     * @param sub 后面追加的地址
     * @return
     */
    public static String site_url(String sub) {
        return site_option("site_url") + sub;
    }

    /**
     * 网站配置项
     *
     * @param key
     * @return
     */
    public static String site_option(String key) {
        return site_option(key, "");
    }

    /**
     * 网站配置项
     *
     * @param key
     * @param defalutValue 默认值
     * @return
     */
    public static String site_option(String key, String defalutValue) {
        if (StringUtils.isBlank(key)) {
            return "";
        }
        return defalutValue;
    }

    /**
     * 截取字符串
     *
     * @param str
     * @param len
     * @return
     */
    public static String substr(String str, int len) {
        if (str.length() > len) {
            return str.substring(0, len);
        }
        return str;
    }

    /**
     * 返回日期
     *
     * @return
     */
    public static String dateFormat(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return format.format(date);
    }

    /**
     * 返回新闻链接地址
     *
     * @param id
     * @return
     */
    public static String permalink(Integer id) {
        return site_url("/news/" + id.toString());
    }

    /**
     * 截取新闻摘要
     *
     * @param news 新闻
     * @param len   要截取文字的个数
     * @return
     */
    public static String intro(News news, int len) {
        String value = news.getContent();
        int pos = value.indexOf("<!--more-->");
        if (pos != -1) {
            String html = value.substring(0, pos);
            return MyUtils.htmlToText(MyUtils.mdToHtml(html));
        } else {
            String text = MyUtils.htmlToText(MyUtils.mdToHtml(value));
            if (text.length() > len) {
                return text.substring(0, len)+"......";
            }
            return text;
        }
    }

    /**
     * 对文章内容进行格式转换，将Markdown为Html
     * @param value
     * @return  ok
     */
    public static String news(String value) {
        if (StringUtils.isNotBlank(value)) {
            value = value.replace("<!--more-->", "\r\n");
            return MyUtils.mdToHtml(value);
        }
        return "";
    }

    /**
     * TODO 处理发布新闻图片
     * 显示新闻 图，顺序为：新闻第一张图 -> 随机获取
     *
     * @return
     */
    public static String show_thumb(News news) {
        if (StringUtils.isNotBlank(news.getPhoto())){
            return news.getPhoto();
        }
        int cid = news.getId();
        int size = cid % 22;//TODO  尝试替换10 ?数据库有12条数据
        size = size == 0 ? 1 : size;
        return "/user/img/random/" + size + ".png";
        // todo 处理图片

    }

    /**
     * 这种格式的字符转换为emoji表情
     *
     * @param value
     * @return
     */
    public static String emoji(String value) {
        return EmojiParser.parseToUnicode(value);
    }

}

