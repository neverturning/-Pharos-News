package com.wan.pharosnews.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import com.vdurmont.emoji.EmojiParser;
import com.wan.pharosnews.dao.CommentMapper;
import com.wan.pharosnews.dao.NewsMapper;
import com.wan.pharosnews.dao.StatisticMapper;
import com.wan.pharosnews.model.domain.News;
import com.wan.pharosnews.model.domain.Statistic;
import com.wan.pharosnews.service.NewsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.data.redis.core.RedisTemplate;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class NewsServiceImpl implements NewsService {
    private static final Logger logger = LoggerFactory.getLogger(NewsServiceImpl.class);
    @Autowired
    private NewsMapper newsMapper;
    @Autowired
    private StatisticMapper statisticMapper;
    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private CommentMapper commentMapper;


    //todo 分页查询新闻列表
    @Override
    public PageInfo<News> selectNewsWithPage(Integer page,Integer count) {
        PageHelper.startPage(page,count);
        List<News>newsList = newsMapper.selectNewsWithPage(); //todo 根据ID降序查找并把内容存储在列表newlist中
        logger.info("newsList:"+newsList);
        //封装新闻统计数据
        for (int i = 0 ; i<newsList.size();i++){
            News news = newsList.get(i);
            Statistic statistic = statisticMapper.findStatisticByNewId(news.getId());
            news.setHits(statistic.getHits());
            news.setCommentsNum(statistic.getCommentsNum());
        }
        PageInfo<News> pageInfo = new PageInfo<>(newsList);
//        logger.info("pageInfo:"+pageInfo);
        return pageInfo;
    }

    @Override
    public PageInfo<News> selectNewBytitle(Integer page,Integer count,String title) {
        PageHelper.startPage(page,count);
        List<News>newsList = newsMapper.selectNewBytitle(title);
        for (News news : newsList) {
            Statistic statistic = statisticMapper.findStatisticByNewId(news.getId());
            news.setHits(statistic.getHits());
            news.setCommentsNum(statistic.getCommentsNum());
        }
        PageInfo<News>pageInfo = new PageInfo<>(newsList);
        return pageInfo;
    }

    //todo 统计前十的热度文章信息
    @Override
    public List<News> getHeatNews() {

        List<Statistic> list = statisticMapper.getStatistic();
        List<News> newsList = new ArrayList<>();
        for(int i = 0 ;i < list.size();i++) {
            News news = newsMapper.selectNewsId(list.get(i).getNewId());
            news.setHits(list.get(i).getHits());
            news.setCommentsNum(list.get(i).getCommentsNum());
            newsList.add(news);
            if(i>=9) {break;}
        }
//        logger.info("newsList:"+newsList);
        return newsList;

    }

    // todo 根据id查询单个新闻详情，并使用Redis进行缓存管理
    public News selectNewsId (Integer id){
        News news = null;
        Object o = redisTemplate.opsForValue().get("new"+id);
        if(o!=null){
            news=(News) o;
        }else{
            news = newsMapper.selectNewsId(id);
            if(news!=null){
                redisTemplate.opsForValue().set("new" + id,news);
            }
        }
        return news;

    }

    //todo 发布新闻
    @Override
    public void publish(News news) {
        news.setContent(EmojiParser.parseToAliases(news.getContent()));
        news.setCreatedate(new Date());
        news.setHits(0);
        news.setCommentsNum(0);
        //插入发布新闻，并插入文章统计数据
        newsMapper.publishNews(news);
        statisticMapper.addStatistic(news);
    }

    //todo 更新新闻
    @Override
    public void updateNewsWithId(News news) {
        news.setModified(new Date());
        newsMapper.updateNewsWithId(news);
        redisTemplate.delete("new"+news.getId());//更新后根据newsid去除掉缓存

    }

    //todo 删除新闻
//todo 删除新闻的同时，要删除缓存数据、相关评论以及相关统计数据，
// 可优化为更新并非删除数据库数据而是更新数据库把数据置0
// 但数据库默认只显示数据为1的数据
    @Override
    public void deleteNewsWithId(int id) {
        newsMapper.deleteNewsWithId(id);
        redisTemplate.delete("new"+id);
        statisticMapper.deleteStatisticWithId(id);
        commentMapper.deleteCommentWithId(id);

    }
}
