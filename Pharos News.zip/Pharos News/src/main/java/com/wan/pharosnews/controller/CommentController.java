package com.wan.pharosnews.controller;

import com.vdurmont.emoji.EmojiParser;
import com.wan.pharosnews.model.ResponseDate.NewsResponseData;
import com.wan.pharosnews.model.ResponseDate.StaticticsBo;
import com.wan.pharosnews.model.domain.Comment;
import com.wan.pharosnews.model.domain.News;
import com.wan.pharosnews.service.CommentService;
import com.wan.pharosnews.utils.MyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;


@Controller
@RequestMapping("/comments")
public class CommentController {
    //todo psfLl = LF.gL(.class)
    private static final Logger  logger = LoggerFactory.getLogger(CommentController.class);
    @Autowired
    private CommentService commentService;

    // 发表评论操作
    @PostMapping(value = "/publish")
    @ResponseBody
    public NewsResponseData publishComment(HttpServletRequest request, @RequestParam Integer id, @RequestParam String text) {
        // 去除js脚本

        text = MyUtils.cleanXSS(text);
        text = EmojiParser.parseToAliases(text);
        // 获取当前登录用户
        User user=(User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        // 封装评论信息
        Comment comments = new Comment();
        comments.setNewid(id);
        comments.setIp(request.getRemoteAddr());
        comments.setCreatedate(new Date());
        comments.setAuthor(user.getUsername());
        comments.setContent(text);
//        logger.info("text:"+text);
        try {
            commentService.pushComment(comments);
            logger.info("发布评论成功，对应新闻id: "+id);
            return NewsResponseData.ok();
        } catch (Exception e) {
            logger.error("发布评论失败，对应新闻id: "+id +";错误描述: "+e.getMessage());
            return NewsResponseData.fail();
        }
    }


}
