package com.wan.pharosnews.dao;

import com.wan.pharosnews.model.domain.Userall;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserallMapper {

   public List<Userall>getUserall();
}
