package com.wan.pharosnews.model.domain;

import java.util.Date;
// todo new表中
public class News {
    private Integer id; //  新闻ID
    private String title; //  新闻标题
    private String content; //  新闻内容
    private Date createdate; // 新闻创建时间
    private Date modified; // 新闻修改时间
    private String categories;  // 新闻分类
    private Boolean allowcomment; // 新闻是否允许评论
    private String tags;      // 新闻标签
    private String photo;     // 新闻图片

    // TODO statistic表中
    private Integer hits;         // 点击量
    private Integer commentsNum;  // 评论总量

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }

    public String getCategories() {
        return categories;
    }

    public void setCategories(String categories) {
        this.categories = categories;
    }

    public Boolean getAllowcomment() {
        return allowcomment;
    }

    public void setAllowcomment(Boolean allowcomment) {
        this.allowcomment = allowcomment;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public Integer getHits() {
        return hits;
    }

    public void setHits(Integer hits) {
        this.hits = hits;
    }

    public Integer getCommentsNum() {
        return commentsNum;
    }

    public void setCommentsNum(Integer commentsNum) {
        this.commentsNum = commentsNum;
    }

    @Override
    public String toString() {
        return "New{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", createdate=" + createdate +
                ", modified=" + modified +
                ", categories='" + categories + '\'' +
                ", allowcomment='" + allowcomment + '\'' +
                ", tags='" + tags + '\'' +
                ", photo='" + photo + '\'' +
                ", hits=" + hits +
                ", commentsNum=" + commentsNum +
                '}';
    }
}
