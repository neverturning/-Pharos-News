package com.wan.pharosnews.controller;

import com.github.pagehelper.PageInfo;
import com.wan.pharosnews.model.ResponseDate.NewsResponseData;
import com.wan.pharosnews.model.ResponseDate.StaticticsBo;
import com.wan.pharosnews.model.domain.Comment;
import com.wan.pharosnews.model.domain.News;
import com.wan.pharosnews.model.domain.Userall;
import com.wan.pharosnews.service.CommentService;
import com.wan.pharosnews.service.NewsService;
import com.wan.pharosnews.service.SiteService;
import com.wan.pharosnews.service.UserallService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

//todo 实现新闻查询（显示最新5条），删除，更新（修改），插入（增加）
@Controller
@RequestMapping("/admin")
public class AdminController {
    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private NewsService newsService;
    @Autowired
    private SiteService siteService;
    @Autowired
    private CommentService commentService;
    @Autowired
    private UserallService userallService;

    // 管理中心起始页 todo 最新发布统计
    // todo 对数据进行处理显示当前最新5条新闻、5条评论以及点击量，评论总数等数据
    @GetMapping(value = {"", "/index"})
    public String index(HttpServletRequest request) {
        List<News> news = siteService.recentNews(5);
        List<Comment> comments = siteService.recentComments(5);
        StaticticsBo staticticsBo = siteService.getStatistics();
//        logger.info("news",news);
//        logger.info("comments",comments);
//        logger.info("staticticsBo:",staticticsBo);
        request.setAttribute("comments", comments);
        request.setAttribute("news", news);
        request.setAttribute("statistics", staticticsBo);
        return "back/index";
    }

    // 向文章发表页面跳转
    @GetMapping(value = "/news/toEditPage")
    public String newNews() {
        return "back/news_edit";
    }

    // 发表新闻，TODO 插入操作
    @PostMapping(value = "/news/publish")
    @ResponseBody
    public NewsResponseData publishNews(News news) {
        if (StringUtils.isBlank(news.getCategories())) {
            news.setCategories("默认分类"); //分类为空则为默认分类
        }
        try {
            newsService.publish(news);
            logger.info("新闻发布成功");
            return NewsResponseData.ok();
        } catch (Exception e) {
            logger.error("新闻发布失败,错误信息:" + e.getMessage());
            return NewsResponseData.fail();

        }
    }

    // 跳转到后台文章列表页面
    @GetMapping(value = "/news")
    public String index(@RequestParam(value = "page", defaultValue = "1") int page,
                        @RequestParam(value = "count", defaultValue = "10") int count,
                        HttpServletRequest request) {
        PageInfo<News> pageInfo = newsService.selectNewsWithPage(page, count);
        request.setAttribute("news", pageInfo);
        return "back/news_list";
    }

    // 对新闻进行修改页面， TODO 更新操作 update
    @GetMapping(value = "/news/{id}")
    public String editNews(@PathVariable("id") String id, HttpServletRequest request) {
        News news = newsService.selectNewsId(Integer.parseInt(id));
        request.setAttribute("contents", news);
        request.setAttribute("categories", news.getCategories());
        return "back/news_edit";
    }

    // 新闻修改处理
    @PostMapping(value = "/news/modify")
    @ResponseBody
    public NewsResponseData modifyNews(News news) {
        try {
            newsService.updateNewsWithId(news);
            logger.info("新闻更新成功");
            return NewsResponseData.ok();
        } catch (Exception e) {
            logger.error("新闻更新失败" + e.getMessage());
            return NewsResponseData.fail();

        }
    }

    // 新闻删除 todo 根据新闻id删除
    @PostMapping(value = "/news/delete")
    @ResponseBody
    public NewsResponseData delete(@RequestParam int id) {
        try {
            newsService.deleteNewsWithId(id);
            logger.info("删除操作成功");
            return NewsResponseData.ok();

        } catch (Exception e) {
            logger.error("删除操作失败" + e.getMessage());
            return NewsResponseData.fail();

        }
    }

    //评论管理
    @GetMapping(value = "/news/toManagerComment")
    public String Commentlist(HttpServletRequest request) {
        List<Comment> commentList = commentService.selectAllComment();
        logger.info(String.valueOf(commentList));
        request.setAttribute("comment", commentList);
        return "back/comment_list";
    }


    // 评论删除 todo 根据评论id删除
    @PostMapping(value = "/comment/delete")
    @ResponseBody
    public NewsResponseData deleteCommentById(@RequestParam int id) {
        try {
            commentService.deleteCommentById(id);
            logger.info("删除操作成功");
            return NewsResponseData.ok();

        } catch (Exception e) {
            logger.error("删除操作失败" + e.getMessage());
            return NewsResponseData.fail();

        }
    }


    //用户管理
    @GetMapping(value = "/news/toManagerUserall")
    public String Useralllist(HttpServletRequest request) {
        List<Userall> userallList = userallService.getUserall();
        logger.info(String.valueOf(userallList));
        request.setAttribute("userall", userallList);
        return "back/userall_list";
    }

    @PostMapping(value = "/user/delete")
    @ResponseBody
    public NewsResponseData deleteUserById(@RequestParam int id) {
        try {
            userallService.deleteUabyId(id);
            userallService.deleteUserbyId(id);
            logger.info("删除操作成功");
            return NewsResponseData.ok();

        } catch (Exception e) {
            logger.error("删除操作失败" + e.getMessage());
            return NewsResponseData.fail();

        }
    }
    @PostMapping(value = "/user/update/plus")
    @ResponseBody
    public NewsResponseData updateplusUserById(@RequestParam int id) {
        try {
            userallService.plusauthority(id);
            logger.info("更新操作成功");
            return NewsResponseData.ok();

        } catch (Exception e) {
            logger.error("更新操作失败" + e.getMessage());
            return NewsResponseData.fail();

        }
    }

    @PostMapping(value = "/user/update/down")
    @ResponseBody
    public NewsResponseData updatedownUserById(@RequestParam int id) {
        try {
            userallService.downauthority(id);
            logger.info("更新操作成功");
            return NewsResponseData.ok();

        } catch (Exception e) {
            logger.error("更新操作失败" + e.getMessage());
            return NewsResponseData.fail();

        }
    }
}