package com.wan.pharosnews.model.ResponseDate;

/**
 * 全站服务统计类
 */
public class StaticticsBo {
    private Integer news;
    private Integer comments;

    public Integer getNews() {
        return news;
    }

    public void setNews(Integer news) {
        this.news = news;
    }

    public Integer getComments() {
        return comments;
    }

    public void setComments(Integer comments) {
        this.comments = comments;
    }

    @Override
    public String toString() {
        return "StaticticsBo{" +
                "news=" + news +
                ", comments=" + comments +
                '}';
    }
}
