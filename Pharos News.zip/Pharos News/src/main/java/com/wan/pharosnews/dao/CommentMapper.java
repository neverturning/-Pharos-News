package com.wan.pharosnews.dao;

import com.wan.pharosnews.model.domain.Comment;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CommentMapper {
    // 分页展示某个新闻的评论
    @Select("SELECT * FROM comment WHERE newid=#{id} ORDER BY id DESC")
    public List<Comment> selectCommentWithPage(Integer id);// newid

    // 后台查询最新几条评论
    @Select("SELECT * FROM comment ORDER BY id DESC")
    public List<Comment> selectNewComment();

    // 发表评论
    @Insert("INSERT INTO comment (newid,createdate,author,ip,content)" +
            " VALUES (#{newid}, #{createdate},#{author},#{ip},#{content})")
    public void pushComment(Comment comment);

    // 站点服务统计，统计评论数量
    @Select("SELECT COUNT(1) FROM comment")
    public Integer countComment();

    // 通过新闻id删除评论信息
    @Delete("DELETE FROM comment WHERE newid=#{id}")// newid
    public void deleteCommentWithId(Integer id);

    @Delete("DELETE FROM comment WHERE id=#{id}")
    public void deleteCommentById(Integer id);

}
