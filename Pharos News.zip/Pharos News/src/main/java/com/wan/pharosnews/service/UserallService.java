package com.wan.pharosnews.service;

import com.wan.pharosnews.model.domain.User;
import com.wan.pharosnews.model.domain.Userall;

import java.util.List;

public interface UserallService {

    public List<Userall>getUserall();

    public int register(User user );

    public void deleteUserbyId(int id);

    public void deleteUabyId(int id);

    public void plusauthority(int id);

    public void downauthority(int id);


}
