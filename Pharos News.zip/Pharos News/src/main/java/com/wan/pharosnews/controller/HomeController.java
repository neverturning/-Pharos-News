package com.wan.pharosnews.controller;

import com.github.pagehelper.PageInfo;

import com.wan.pharosnews.model.domain.Comment;
import com.wan.pharosnews.model.domain.News;
import com.wan.pharosnews.service.CommentService;
import com.wan.pharosnews.service.NewsService;

import com.wan.pharosnews.service.SiteService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
public class HomeController {
    private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

    @Autowired
    private NewsService newsServiceImpl;
    @Autowired
    private CommentService commentServiceImpl;
    @Autowired
    private SiteService siteServiceImpl;

//todo 首页  一页显示五条新闻
    @GetMapping(value = "/")
    public String home(HttpServletRequest request){
        return this.home(request,1,5);
    }

    @GetMapping(value = "/page/{p}")
    public String home(HttpServletRequest request,
                       @PathVariable("p") int page,
                       @RequestParam(value = "count",defaultValue = "5")int count ){
        PageInfo<News> news = newsServiceImpl.selectNewsWithPage(page,count);
        // 获取新闻热度统计信息
        List<News> newsList = newsServiceImpl.getHeatNews();
//        logger.info("newsList "+newsList);
        //todo 数据存储在request域中。
        // 后端通过request将数据发送给前端页面
        request.setAttribute("news", news);
        request.setAttribute("newsList", newsList);
        return "client/home";

    }

    @GetMapping(value = "/page/{p}/title")
    public String selectNewBytitle(HttpServletRequest request,
                                   @PathVariable("p") int page,
                                   @RequestParam(value = "count",defaultValue = "5")int count,
                                   String title){
        PageInfo<News> news = newsServiceImpl.selectNewBytitle(page,count,title);
//        logger.info(String.valueOf(news));
        List<News> newsList = newsServiceImpl.getHeatNews();
        request.setAttribute("news",news);
        request.setAttribute("newsList", newsList);
        return  "client/home";

    }
    // 新闻详情查询
    @GetMapping(value = "/news/{id}")
    public String getNewsById(@PathVariable("id") Integer id, HttpServletRequest request){
        News news = newsServiceImpl.selectNewsId(id);
        if(news!=null){
            // 查询封装评论相关数据
            getNewsComments(request, news);
            // 更新文章点击量
            siteServiceImpl.updateStatistics(news);
            request.setAttribute("news",news);
            return "client/newsDetails";
        }else {
            logger.warn("查询文章详情结果为空，查询文章id: "+id);
            // 未找到对应文章页面，跳转到提示页
            return "comm/error_404";  // todo temp null
        }
    }

    // 查询文章的评论信息，并补充到文章详情里面
    private void getNewsComments(HttpServletRequest request, News news) {
        if (news.getAllowcomment()) {
            // cp表示评论页码，commentPage
            String cp = request.getParameter("cp");
            cp = StringUtils.isBlank(cp) ? "1" : cp;
            request.setAttribute("cp", cp);
            PageInfo<Comment> comments = commentServiceImpl.getComments(news.getId(),Integer.parseInt(cp),3);
            request.setAttribute("cp", cp);
            request.setAttribute("comments", comments);
        }
    }


}
