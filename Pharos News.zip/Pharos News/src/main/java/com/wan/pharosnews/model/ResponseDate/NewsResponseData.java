package com.wan.pharosnews.model.ResponseDate;


public class NewsResponseData<T> {
    private T payload;        //服务器响应数据
    private boolean success; //请求是否成功
    private String msg;       // 错误信息
    private int code = -1;   // 状态码
    private long timestamp; //服务器响应时间

    public NewsResponseData(){
        this.timestamp = System.currentTimeMillis() / 1000;
    }

    public NewsResponseData(boolean success) {
        this.timestamp = System.currentTimeMillis() / 1000;
        this.success = success;
    }

    public NewsResponseData(boolean success, T payload) {
        this.timestamp = System.currentTimeMillis() / 1000;
        this.success = success;
        this.payload = payload;
    }

    public NewsResponseData(boolean success, T payload, int code) {
        this.timestamp = System.currentTimeMillis() / 1000;
        this.success = success;
        this.payload = payload;
        this.code = code;
    }

    public NewsResponseData(boolean success, String msg) {
        this.timestamp = System.currentTimeMillis() / 1000;
        this.success = success;
        this.msg = msg;
    }

    public NewsResponseData(boolean success, String msg, int code) {
        this.timestamp = System.currentTimeMillis() / 1000;
        this.success = success;
        this.msg = msg;
        this.code = code;
    }

    public T getPayload() {
        return payload;
    }

    public void setPayload(T payload) {
        this.payload = payload;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    public static NewsResponseData ok() {
        return new NewsResponseData(true);
    }

    public static <T>NewsResponseData ok(T payload) {
        return new NewsResponseData(true, payload);
    }

    public static <T> NewsResponseData ok(int code) {
        return new NewsResponseData(true, null, code);
    }

    public static <T> NewsResponseData ok(T payload, int code) {
        return new NewsResponseData(true, payload, code);
    }

    public static NewsResponseData fail() {
        return new NewsResponseData(false);
    }

    public static NewsResponseData fail(String msg) {
        return new NewsResponseData(false, msg);
    }

    public static NewsResponseData fail(int code) {
        return new NewsResponseData(false, null, code);
    }

    public static NewsResponseData fail(int code, String msg) {
        return new NewsResponseData(false, msg, code);
    }

}
