package com.wan.pharosnews.dao;

import com.wan.pharosnews.model.domain.User;
import org.apache.ibatis.annotations.*;

@Mapper
public interface UserMapper {
    @Insert("insert into user(username,password) values(#{username},#{password})")
    @Options(useGeneratedKeys = true , keyProperty = "id" ,keyColumn = "id")
    public int  register(User user);

    @Insert("insert into user_authority(customer_id) values(#{customerid})")
    public void insertua(int customerid);

    @Delete("DELETE FROM USER WHERE id=#{id}")
    public void  deleteUserbyId(Integer id);

    @Delete("DELETE FROM user_authority WHERE customer_id=#{id}")
    public void  deleteUabyId(Integer id);

    @Update("update user_authority set authority_id='1' where customer_id=#{id}")
    public  void plusauthority(Integer id);

    @Update("update user_authority set authority_id='2' where customer_id=#{id}")
    public  void downauthority(Integer id);
}
