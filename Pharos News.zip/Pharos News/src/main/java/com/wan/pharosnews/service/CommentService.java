package com.wan.pharosnews.service;

import com.github.pagehelper.PageInfo;
import com.wan.pharosnews.model.domain.Comment;

import java.util.List;

public interface CommentService {

    // 获取新闻下的评论
    public PageInfo<Comment> getComments(Integer id, int page, int count);

    // 用户发表评论
    public void pushComment(Comment comment);

    public List<Comment> selectAllComment();

    public void  deleteCommentById(int id);

}
