package com.wan.pharosnews.controller;

import com.wan.pharosnews.model.domain.User;
import com.wan.pharosnews.service.UserallService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * @program: pharos-news
 * @description:
 * @author: wan
 * @create: 2022-04-06 23:09
 **/
@Controller
public class RegisterController {
    private static final Logger logger = LoggerFactory.getLogger(CommentController.class);
    @Autowired
    UserallService userallServicel;

    // 跳转注册界面
    @GetMapping(value = "/toregister")
    public String toregister() {
        return "comm/register";
    }

    @GetMapping("/register")
    public String register( String username, String password, User user)throws Exception {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        // 对明文密码加密
        String enpassword = passwordEncoder.encode(password);
        user.setUsername(username);
        user.setPassword(enpassword);
        if (user.getUsername()==null||user.getPassword()==null)
            throw new Exception("注册信息不能为空");
        if(userallServicel.register(user)>0){
            System.out.println("注册失败");
            return "comm/register";
        }

        System.out.println("注册成功");
        return "comm/login";
    }
}
