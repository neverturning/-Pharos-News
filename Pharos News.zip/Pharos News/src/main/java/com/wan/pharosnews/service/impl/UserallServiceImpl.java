package com.wan.pharosnews.service.impl;

import com.wan.pharosnews.dao.UserMapper;
import com.wan.pharosnews.dao.UserallMapper;
import com.wan.pharosnews.model.domain.User;
import com.wan.pharosnews.model.domain.Userall;
import com.wan.pharosnews.service.UserallService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @program: pharos-news
 * @description:
 * @author: wan
 * @create: 2022-04-06 00:21
 **/
@Service
@Transactional
public class UserallServiceImpl implements UserallService {
    @Autowired
    UserallMapper userallMapper;
    @Autowired
    UserMapper userMapper;
    @Override
    public List<Userall> getUserall() {
        List<Userall>userallList = userallMapper.getUserall();
        return userallList;
    }

    @Override
    public int register(User user) {
        userMapper.register(user);
        userMapper.insertua(user.getId());
        return 0;

    }

    @Override
    public void deleteUserbyId(int id) {
        userMapper.deleteUserbyId(id);
    }

    @Override
    public void deleteUabyId(int id) {
        userMapper.deleteUabyId(id);
    }

    @Override
    public void plusauthority(int id) {
        userMapper.plusauthority(id);
    }

    @Override
    public void downauthority(int id) {
        userMapper.downauthority(id);
    }

}
