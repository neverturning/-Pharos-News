package com.wan.pharosnews;

        import com.wan.pharosnews.dao.*;
        import com.wan.pharosnews.model.domain.*;
        import org.junit.Test;
        import org.junit.runner.RunWith;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.boot.test.context.SpringBootTest;
        import org.springframework.test.context.junit4.SpringRunner;

        import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PharosNewsApplicationTests {
    @Autowired
    private NewsMapper newsMapper;
    @Test
    public void selectNewsId (){
        News news = newsMapper.selectNewsId(1);
        System.out.println(news);

    }

    @Test
    public void selectNewBytitle (){
        List<News>newsList= newsMapper.selectNewBytitle("从");

        System.out.println(newsList);

    }



    @Autowired
    private StatisticMapper statisticMapper;
    @Test
    public void findStatisticByNewId( ){
        Statistic statistic = statisticMapper.findStatisticByNewId(1);
        System.out.println(statistic);

    }

    @Autowired
    private CommentMapper commentMapper;
    @Test
    public void selectCommentWithPage(){
        List<Comment> commentList = commentMapper.selectCommentWithPage(1);
        System.out.println(commentList);

    }

    @Autowired
    private UserallMapper userallMapper;
    @Test
    public void selectuser(){
        List<Userall> userallList = userallMapper.getUserall();
        System.out.println(userallList);

    }


    @Autowired
    private UserMapper userMapper;
    @Test
    public void Insertuser(){
        User user = new User();
        user.setUsername("姗姗4");
        user.setPassword("122331");


        System.out.println("插入前:"+user);

               userMapper.register(user);
               userMapper.insertua(user.getId());
               int  count =user.getId();
        System.out.println("返回值"+user.getId());






    }
    @Test
    public void plusau() {
        userMapper.plusauthority(1);
        List<Userall> userallList = userallMapper.getUserall();
        System.out.println(userallList);


    }

}
